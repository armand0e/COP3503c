Name: Arman Rafiee
Section: 17947
UFL email: a.rafiee@ufl.edu
System: Windows
Compiler: g++
SFML version: 2.6.1
IDE: Visual Studio Code
Other notes: Compatible with SFML-2.5.1